tinymce - build: 5.0.0-rc-1-build.3-1

Documentation
-----------------
For detailed documentation, please see the following locations:

https://www.tinymce.com/docs/get-started/  - Installation
https://www.tinymce.com/docs/api/          - API Reference

Support
-----------------
For further support, please use the Ephox Support website, located here: https://support.ephox.com/home
